package vistarnet.manu.com.flavaco;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.io.InputStream;
import java.text.SimpleDateFormat;

public class couponActivity extends AppCompatActivity {

    TextView txtTimer,timestamp ;
    private long startTime = 0L;
    private Handler customHandler = new Handler();
    long timeInMilliseconds = 0L;
    long timeSwapBuff = 0L;
    long updatedTime = 0L;
    private AdView mAdView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coupon);

        ImageView bindImage = (ImageView) findViewById(R.id.imageView);
        String Hid,timer;
        Hid = getIntent().getStringExtra(App_Config_Value.COUPON_HOTEL_ID);
        int HotelId = Integer.parseInt(Hid);
        if(HotelId == 101){
            bindImage.setImageResource(R.drawable.shetty);

        }else{
            if(HotelId == 102){
                bindImage.setImageResource(R.drawable.suresh);
            }
            else{
                String HIMAGE = getIntent().getStringExtra(App_Config_Value.COUPON_IMAGE);
                couponActivity.DownloadImageWithURLTask downloadTask = new couponActivity.DownloadImageWithURLTask(bindImage);
                downloadTask.execute(HIMAGE);
            }
        }


        timer = getIntent().getStringExtra(App_Config_Value.COUPON_TIMER);
        int time = Integer.parseInt(timer);
        timestamp = (TextView)findViewById(R.id.timestamp);
        long date = System.currentTimeMillis();


        MobileAds.initialize(this, "ca-app-pub-2170195758235926~2230171851");
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        SimpleDateFormat sdf = new SimpleDateFormat(" dd MMM h:mm a");
        String dateString = sdf.format(date);
        timestamp.setText(dateString);

        txtTimer = (TextView)findViewById(R.id.timertext);
        startTime = SystemClock.uptimeMillis();
        customHandler.postDelayed(updateTimerThread, 0);
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                finish();
            }
        }, time*1000);
    }

    private Runnable updateTimerThread = new Runnable() {
        public void run() {
            timeInMilliseconds = SystemClock.uptimeMillis() - startTime;
            updatedTime = timeSwapBuff + timeInMilliseconds;
            int secs = (int) (updatedTime / 1000);
            int mins = secs / 60;
            secs = secs % 60;
            int milliseconds = (int) (updatedTime % 1000);
            txtTimer.setText("" + mins + ":"+ String.format("%02d", secs) + ":"+ String.format("%03d", milliseconds));
            customHandler.postDelayed(this, 0);
        }



    };



    private class DownloadImageWithURLTask extends AsyncTask<String,Void,Bitmap> {
        ImageView bmImage ;
        public DownloadImageWithURLTask(ImageView bmImage){
            this.bmImage = bmImage ;
        }

        protected Bitmap doInBackground(String... urls){
            String pathToFile = urls[0];
            Bitmap bitmap = null ;
            try {
                InputStream in = new java.net.URL(pathToFile).openStream();
                bitmap = BitmapFactory.decodeStream(in);

            }catch(Exception e){

            }
            return bitmap;
        }
        protected  void onPostExecute(Bitmap result){
            bmImage.setImageBitmap(result);




        }
    }
}
