package vistarnet.manu.com.flavaco;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.InputStream;

public class ImageLoader2 extends AppCompatActivity {

    Button close,visit;
    int activityID ;
    String url ;
    private DatabaseHelper db ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_loader2);


        activityID = getIntent().getIntExtra(App_Config_Value.INTENT_ACTIVITY_ID,0);
        if(activityID > 2){
            url = getIntent().getStringExtra(App_Config_Value.INTENT_ACTIVITY_URL);
        }


        db = new DatabaseHelper(this);


        SharedPreferences prefs = getSharedPreferences(App_Config_Value.MY_SHRD_PREFS_NAME, MODE_PRIVATE);
        int id = prefs.getInt(App_Config_Value.SHRD_ID_KEY, 101); //0 is the default value.

        int count = db.getHotelCount();
        int start = db.getFirstId();


        //Receive HURL HIMAGE from previous activity
        final String HURL = db.getURL(id).gethotelpage();
        String HIMAGE = db.getURL(id).getHotelimg();
        id = id + 1;
        if (start + count - 1 < id) {
            id = start;
        }
        SharedPreferences.Editor editor = getSharedPreferences(App_Config_Value.MY_SHRD_PREFS_NAME, Context.MODE_PRIVATE).edit();
        editor.putInt(App_Config_Value.SHRD_ID_KEY, id);
        editor.apply();


        //Initialise the buttons and ImageView
        close = (Button) findViewById(R.id.close);
        visit = (Button) findViewById(R.id.visit);
        ImageView bindImage = (ImageView) findViewById(R.id.imageView);




        //Set Onclick Listener for visit button
        setVisitButtonListener(HURL);
        close.setEnabled(false);
        //close Button timer
        closeButtonTimer();

        //This task is to show the image ad in the image View
        ImageLoader2.DownloadImageWithURLTask downloadTask = new ImageLoader2.DownloadImageWithURLTask(bindImage);
        downloadTask.execute(HIMAGE);

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i ;
                switch (activityID){
                    case 1 : i = new Intent(ImageLoader2.this, hotelsActivity.class);
                        break ;
                    case 2 : i = new Intent(ImageLoader2.this, barCodeActivity.class);
                        break ;
                    case 3 : i = new Intent(ImageLoader2.this,PendriveActivity.class);
                        i.putExtra(App_Config_Value.INTENT_ACTIVITY_URL,url);break ;
                    case 4 : i = new Intent(ImageLoader2.this,TemperedActivity.class);
                        i.putExtra(App_Config_Value.INTENT_ACTIVITY_URL,url);break ;
                    case 5 : i = new Intent(ImageLoader2.this,ClothsActivity.class);
                        i.putExtra(App_Config_Value.INTENT_ACTIVITY_URL,url);break ;
                    case 6 : i = new Intent(ImageLoader2.this,ExtraActivity.class);
                        i.putExtra(App_Config_Value.INTENT_ACTIVITY_URL,url);break ;
                    default:i = new Intent(ImageLoader2.this,hotelsActivity.class);
                }

                startActivity(i);
                finish();

            }

        });
    }





    public void setVisitButtonListener(final String u)
    {
        visit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url = u;
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);

            }
        });
    }

    public void closeButtonTimer()
    {
        new CountDownTimer(3000, 1000) {

            public void onTick(long millisUntilFinished) {
                close.setText(""+millisUntilFinished / 1000);
            }

            public void onFinish() {
                close.setText("X");
                close.setEnabled(true);
            }
        }.start();
    }



    private class DownloadImageWithURLTask extends AsyncTask<String,Void,Bitmap> {
        ImageView bmImage ;
        public DownloadImageWithURLTask(ImageView bmImage){
            this.bmImage = bmImage ;
        }

        protected Bitmap doInBackground(String... urls){
            String pathToFile = urls[0];
            Bitmap bitmap = null ;
            try {
                InputStream in = new java.net.URL(pathToFile).openStream();
                bitmap = BitmapFactory.decodeStream(in);

            }catch(Exception e){

            }
            return bitmap;
        }
        protected  void onPostExecute(Bitmap result){
            bmImage.setImageBitmap(result);




        }
    }
}
