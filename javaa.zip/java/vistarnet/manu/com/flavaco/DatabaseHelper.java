package vistarnet.manu.com.flavaco;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
/**
 * Created by manish channawar on 03-11-2018.
 */

public class DatabaseHelper extends SQLiteOpenHelper{
    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "hotel_tb";


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(hotelDBInfo.CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + hotelDBInfo.TABLE_NAME);


        // Create tables again
        onCreate(db);
    }

    //return number of hotels
    public int getHotelCount() {
        String countQuery = "SELECT  * FROM " + hotelDBInfo.TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int count = cursor.getCount();
        cursor.close();
        // return count
        return count;
    }


    //insert a row into database
    public long insertNote(int id,String hurl,String hImageUrl) {
        // get writable database as we want to write data
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        // `id` and `timestamp` will be inserted automatically.
        // no need to add them
        values.put(hotelDBInfo.COLUMN_ID, id);
        values.put(hotelDBInfo.COLUMN_HOTEL_PAGE, hurl);
        values.put(hotelDBInfo.COLUMN_HOTEL_IMG, hImageUrl);

        // insert row
        long res = db.insert(hotelDBInfo.TABLE_NAME, null, values);

        // close db connection
        db.close();

        // return newly inserted row id
        return res;
    }

    //returns image and page url
    public hotelDBInfo getURL(long id) {
        // get readable database as we are not inserting anything
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(hotelDBInfo.TABLE_NAME,
                new String[]{hotelDBInfo.COLUMN_ID, hotelDBInfo.COLUMN_HOTEL_PAGE, hotelDBInfo.COLUMN_HOTEL_IMG},
                hotelDBInfo.COLUMN_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        // prepare note object
        hotelDBInfo note = new hotelDBInfo(
                cursor.getInt(cursor.getColumnIndex(hotelDBInfo.COLUMN_ID)),
                cursor.getString(cursor.getColumnIndex(hotelDBInfo.COLUMN_HOTEL_PAGE)),
                cursor.getString(cursor.getColumnIndex(hotelDBInfo.COLUMN_HOTEL_IMG)));

        // close the db connection
        cursor.close();

        return note;
    }

    public int getFirstId(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.query(hotelDBInfo.TABLE_NAME, new String[] { "min(" + hotelDBInfo.COLUMN_ID + ")" }, null, null,
                null, null, null);
        c.moveToFirst();  //ADD THIS!
        int rowID = c.getInt(0);
        c.close();
        return rowID;

    }



    //delete all rows
    public void deleteAllRows() {

        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from "+hotelDBInfo.TABLE_NAME);
        db.close();

    }
}
