package vistarnet.manu.com.flavaco;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.PopupMenu;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;

import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Register2 extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {
    String NAME;
    Button verify;
    private ProgressDialog pDialog;
    EditText otp ;
    JSONParser jParser = new JSONParser();


    private AdView mAdView;
    private InterstitialAd mInterstitialAd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register2);

        Bundle b = getIntent().getExtras();
        final String PHONE = b.getString(App_Config_Value.PHONE);
        NAME = b.getString(App_Config_Value.NAME);


        verify = (Button)findViewById(R.id.btn_verify);
        otp = (EditText)findViewById(R.id.otp);
        otp.setTransformationMethod(null);


        MobileAds.initialize(this, "ca-app-pub-2170195758235926~2230171851");
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("ca-app-pub-2170195758235926/3607666858");
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                // Load the next interstitial.
                mInterstitialAd.loadAd(new AdRequest.Builder().build());
            }

        });



        /////////
        MobileAds.initialize(this, "ca-app-pub-2170195758235926~2230171851");
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        //this class check the hotels and add to database
        new HotelListDownloader(this).checkAndDownloadHotels();

        otpButton(PHONE);


    }

    public void otpButton(final String PHONE){

        verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                verify.setEnabled(false);
                String otp_user = otp.getText().toString();
                if(otp_user.trim().isEmpty())
                {
                    Toast.makeText(Register2.this, "OTP Cannot be Empty", Toast.LENGTH_SHORT).show();
                    verify.setEnabled(true);
                }
                else
                {
                    if(otp_user.trim().length() != 6)
                    {
                        Toast.makeText(Register2.this, "OTP must be 6 numbers", Toast.LENGTH_SHORT).show();
                        verify.setEnabled(true);
                    }else {


                        Register2.OtpVerification atreg = new Register2.OtpVerification();
                        atreg.execute(PHONE, otp_user, "");
                    }

                }
            }
        });

    }







    public void showMenu(View v) {
        PopupMenu popup = new PopupMenu(this, v);

        // This activity implements OnMenuItemClickListener
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.actions);
        popup.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.aboutus:
                if (mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                } else {
                    Log.d("TAG", "The interstitial wasn't loaded yet.");
                }
                Intent i = new Intent(Register2.this,AboutUs.class);
                startActivity(i);
                return true;

            default:
                return false;
        }
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    private class OtpVerification extends AsyncTask<String, String, JSONObject> {

        @Override

        protected void onPreExecute() {

            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(Register2.this);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();
        }

        @Override

        protected JSONObject doInBackground(String... args) {
            ArrayList params = new ArrayList();
            params.add(new BasicNameValuePair("phonenumber", args[0]));
            params.add(new BasicNameValuePair("otp_user", args[1]));

            JSONObject json = new JSONObject();
            try {
                json = jParser.makeHttpRequest(App_Config_Value.URL_FOR_OTP_VERIFICATION, "POST", params);


            }catch (Exception e){


                e.printStackTrace();
            }

            System.out.println(json);
            return (json);

        }

        protected void onPostExecute(JSONObject result) {
            try {
                int error = Integer.parseInt(result.getString(App_Config_Value.ERROR_CODE_STRING));


                if (error == App_Config_Value.HTTP_STATUS_CODE_2 ) {

                    String success = result.getString(App_Config_Value.SUCCESS);
                    String message = result.getString(App_Config_Value.MESSAGE);

                    if(success.equals(App_Config_Value.SER_OTP_TRUE)){
                        Toast.makeText(Register2.this,message, Toast.LENGTH_SHORT).show();
                        String phone = result.getString(App_Config_Value.PHONE);
                        SharedPreferences.Editor editor = getSharedPreferences(App_Config_Value.MY_SHRD_PREFS_NAME, MODE_PRIVATE).edit();
                        editor.putString(App_Config_Value.SHRD_PHONE_KEY,phone);
                        editor.putString(App_Config_Value.SHRD_NAME_KEY,NAME);
                        editor.apply();

                        //Send Intent to HomeActivity
                        Intent i = new Intent(Register2.this, MainActivity.class);
                        i.putExtra(App_Config_Value.PHONE,phone);
                        i.putExtra(App_Config_Value.NAME,NAME);
                        startActivity(i);
                        finish();


                    }
                    else {
                        Toast.makeText(Register2.this,message,Toast.LENGTH_SHORT).show();
                        verify.setEnabled(true);
                    }
                }else {


                    Toast.makeText(Register2.this, "" + result.get(App_Config_Value.ERROR_MESSAGE), Toast.LENGTH_SHORT).show();

                }
            } catch (JSONException e) {
                Toast.makeText(Register2.this, "JSON ERROR", Toast.LENGTH_SHORT).show();

            }


            // Dismiss the progress dialog
            if (pDialog.isShowing())
                pDialog.dismiss();


        }

    }
}

