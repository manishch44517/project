package vistarnet.manu.com.flavaco;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;


import java.io.InputStream;

import com.onesignal.OneSignal;

public class ImageLoader extends AppCompatActivity {

    Button close,visit;
    private DatabaseHelper db ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_loader);

        //this is onesignal push notification
        OneSignal.startInit(this)
                .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification)
                .unsubscribeWhenNotificationsAreDisabled(true)
                .init();

        SharedPreferences t = getSharedPreferences(App_Config_Value.MY_SHRD_PREFS_NAME, MODE_PRIVATE);
        int version = t.getInt(App_Config_Value.SHRD_VERSION_KEY, 0); //0 is the default value.


        if(version == 0 ){
            Intent i = new Intent(ImageLoader.this,RegisterActivity.class);
            startActivity(i);
            finish();

        }else {
            db = new DatabaseHelper(this);


            SharedPreferences prefs = getSharedPreferences(App_Config_Value.MY_SHRD_PREFS_NAME, MODE_PRIVATE);
            int id = prefs.getInt(App_Config_Value.SHRD_ID_KEY, 101); //0 is the default value.

            int count = db.getHotelCount();
            int start = db.getFirstId();


            //Receive HURL HIMAGE from previous activity
            final String HURL = db.getURL(id).gethotelpage();
            String HIMAGE = db.getURL(id).getHotelimg();
            id = id + 1;
            if (start + count - 1 < id) {
                id = start;
            }
            SharedPreferences.Editor editor = getSharedPreferences(App_Config_Value.MY_SHRD_PREFS_NAME, Context.MODE_PRIVATE).edit();
            editor.putInt(App_Config_Value.SHRD_ID_KEY, id);
            editor.apply();


            //Initialise the buttons and ImageView
            close = (Button) findViewById(R.id.close);
            visit = (Button) findViewById(R.id.visit);
            ImageView bindImage = (ImageView) findViewById(R.id.imageView);


            //Set Onclick Listener for visit button
            setVisitButtonListener(HURL);
            close.setEnabled(false);
            //close Button timer
            closeButtonTimer();

            //This task is to show the image ad in the image View
            DownloadImageWithURLTask downloadTask = new DownloadImageWithURLTask(bindImage);
            downloadTask.execute(HIMAGE);

            close.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    Intent i = new Intent(ImageLoader.this, RegisterActivity.class);
                    startActivity(i);
                    finish();

                }

            });

        }
    }


    public void setVisitButtonListener(final String u)
    {
        visit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url = u;
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);

            }
        });
    }

    public void closeButtonTimer()
    {
        new CountDownTimer(3000, 1000) {

            public void onTick(long millisUntilFinished) {
                close.setText(""+millisUntilFinished / 1000);
            }

            public void onFinish() {
                close.setText("X");
                close.setEnabled(true);
            }
        }.start();
    }



    private class DownloadImageWithURLTask extends AsyncTask<String,Void,Bitmap> {
        ImageView bmImage ;
        public DownloadImageWithURLTask(ImageView bmImage){
            this.bmImage = bmImage ;
        }

        protected Bitmap doInBackground(String... urls){
            String pathToFile = urls[0];
            Bitmap bitmap = null ;
            try {
                InputStream in = new java.net.URL(pathToFile).openStream();
                bitmap = BitmapFactory.decodeStream(in);

            }catch(Exception e){

            }
            return bitmap;
        }
        protected  void onPostExecute(Bitmap result){
            bmImage.setImageBitmap(result);




        }
    }
}