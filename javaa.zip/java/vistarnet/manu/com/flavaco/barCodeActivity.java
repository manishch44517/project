package vistarnet.manu.com.flavaco;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
//import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.vision.barcode.Barcode;

import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class barCodeActivity extends AppCompatActivity {
    private ProgressDialog pDialog;
    Button back ;
    // Creating JSON Parser object
    JSONParser jParser = new JSONParser();
    Button scanbtn;
    TextView result;
    public static final int REQUEST_CODE = 100;
    public static final int PERMISSION_REQUEST = 200;



    private AdView mAdView;
    private InterstitialAd mInterstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bar_code);

        back = (Button)findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(barCodeActivity.this,hotelsActivity.class);
                startActivity(i);
                finish();
            }
        });

        MobileAds.initialize(this, "ca-app-pub-2170195758235926~2230171851");
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        scanbtn = (Button) findViewById(R.id.scanbtn);
        result = (TextView) findViewById(R.id.result);
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, PERMISSION_REQUEST);
        }




        scanbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ContextCompat.checkSelfPermission(barCodeActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    Intent intent = new Intent(barCodeActivity.this, ScanActivity.class);
                    startActivityForResult(intent, REQUEST_CODE);

                }
                else{
                    Toast.makeText(barCodeActivity.this, "Camera permission needed!", Toast.LENGTH_SHORT).show();

                    if(ContextCompat.checkSelfPermission(barCodeActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){
                        ActivityCompat.requestPermissions(barCodeActivity.this, new String[]{Manifest.permission.CAMERA}, PERMISSION_REQUEST);
                    }
                }


            }
        });



    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == REQUEST_CODE && resultCode == RESULT_OK){
            if(data != null){
                final Barcode barcode = data.getParcelableExtra("barcode");
                result.post(new Runnable() {
                    @Override
                    public void run() {
                        //send phone and text to server
                        SharedPreferences prefs = getSharedPreferences(App_Config_Value.MY_SHRD_PREFS_NAME, Context.MODE_PRIVATE);
                        String phoneSP = prefs.getString(App_Config_Value.SHRD_PHONE_KEY, "0"); //0 is the default value

                        barCodeActivity.CouponCheck atreg = new barCodeActivity.CouponCheck();
                        atreg.execute(phoneSP,barcode.displayValue.toString());
                    }
                });

            }
        }

    }




    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)  {
        if (Integer.parseInt(android.os.Build.VERSION.SDK) > 5
                && keyCode == KeyEvent.KEYCODE_BACK
                && event.getRepeatCount() == 0) {

            onBackPressed();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }


    @Override
    public void onBackPressed() {

        Intent i = new Intent(barCodeActivity.this,hotelsActivity.class);

        startActivity(i);
        finish();
    }





    private class CouponCheck extends AsyncTask<String, String, JSONObject> {

        @Override

        protected void onPreExecute() {

            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(barCodeActivity.this);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();
        }

        @Override

        protected JSONObject doInBackground(String... args) {
            ArrayList params = new ArrayList();
            params.add(new BasicNameValuePair("phonenumber", args[0]));
            params.add(new BasicNameValuePair("hotel_code", args[1]));

            JSONObject json = new JSONObject();
            try {
                json = jParser.makeHttpRequest(App_Config_Value.URL_FOR_COUPON, "POST", params);


            }catch (Exception e){


                e.printStackTrace();
            }

            System.out.println(json);
            return (json);

        }

        protected void onPostExecute(JSONObject result) {
            try {
                int error = Integer.parseInt(result.getString(App_Config_Value.ERROR_CODE_STRING));


                if (error == App_Config_Value.HTTP_STATUS_CODE_2 ) {

                    String success = result.getString(App_Config_Value.SUCCESS);
                    String message = result.getString(App_Config_Value.MESSAGE);
                    if(success.equals(App_Config_Value.SER_COUPON_TRUE)){
                        Toast.makeText(barCodeActivity.this,message, Toast.LENGTH_SHORT).show();
                        String Iurl = result.getString(App_Config_Value.COUPON_IMAGE);
                        String Hid = result.getString(App_Config_Value.COUPON_HOTEL_ID);
                        String timer = result.getString(App_Config_Value.COUPON_TIMER);
                        //Send Intent to Verification
                        Intent i = new Intent(barCodeActivity.this, couponActivity.class);
                        i.putExtra(App_Config_Value.COUPON_IMAGE,Iurl);
                        i.putExtra(App_Config_Value.COUPON_HOTEL_ID,Hid);
                        i.putExtra(App_Config_Value.COUPON_TIMER,timer);
                        startActivity(i);
                        finish();


                    }

                    else {
                        Toast.makeText(barCodeActivity.this,message,Toast.LENGTH_SHORT).show();
                        Intent i = new Intent(barCodeActivity.this,hotelsActivity.class);
                        startActivity(i);
                        finish();


                    }
                }else {


                    Toast.makeText(barCodeActivity.this, "" + result.get(App_Config_Value.ERROR_MESSAGE), Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(barCodeActivity.this,hotelsActivity.class);
                    startActivity(i);
                    finish();

                }
            } catch (JSONException e) {
                Toast.makeText(barCodeActivity.this, "JSON ERROR", Toast.LENGTH_SHORT).show();



            }


            // Dismiss the progress dialog
            if (pDialog.isShowing())
                pDialog.dismiss();


        }

    }
}
