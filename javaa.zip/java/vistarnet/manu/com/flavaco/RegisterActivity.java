package vistarnet.manu.com.flavaco;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.PopupMenu;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;

import org.apache.http.message.BasicNameValuePair;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


//this class is the one which shows ad of the hotel not the register page

public class RegisterActivity extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {

    int gender ;
    Button register ;
    EditText phoneNum,name;

    private ProgressDialog pDialog;
    // Creating JSON Parser object
    JSONParser jParser = new JSONParser();



    private AdView mAdView;
    private InterstitialAd mInterstitialAd;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);



        SharedPreferences prefs = this.getSharedPreferences(App_Config_Value.MY_SHRD_PREFS_NAME, Context.MODE_PRIVATE);
        String phoneSP = prefs.getString(App_Config_Value.SHRD_PHONE_KEY, "0"); //0 is the default value

        if(!phoneSP.equals("0"))
        {
            //direct login

            Intent i = new Intent(RegisterActivity.this,MainActivity.class);
            i.putExtra(App_Config_Value.PHONE,phoneSP);
            startActivity(i);
            finish();

        }else {

            ////////
            MobileAds.initialize(this, "ca-app-pub-2170195758235926~2230171851");
            mInterstitialAd = new InterstitialAd(this);
            mInterstitialAd.setAdUnitId("ca-app-pub-2170195758235926/3607666858");
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
            mInterstitialAd.setAdListener(new AdListener() {
                @Override
                public void onAdClosed() {
                    // Load the next interstitial.
                    mInterstitialAd.loadAd(new AdRequest.Builder().build());
                }

            });



            /////////
            MobileAds.initialize(this, "ca-app-pub-2170195758235926~2230171851");
            mAdView = findViewById(R.id.adView);
            AdRequest adRequest = new AdRequest.Builder().build();
            mAdView.loadAd(adRequest);


            register = (Button) findViewById(R.id.register);


            //this class check the hotels and add to database
            new HotelListDownloader(this).checkAndDownloadHotels();




            phoneNum = (EditText) findViewById(R.id.registerphone);
            phoneNum.setTransformationMethod(null);
            name = (EditText) findViewById(R.id.nameText);
            //register button
            RegisterButton();
        }

    }



    public void showMenu(View v) {
        PopupMenu popup = new PopupMenu(this, v);

        // This activity implements OnMenuItemClickListener
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.actions);
        popup.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.aboutus:
                if (mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                } else {
                    Log.d("TAG", "The interstitial wasn't loaded yet.");
                }
                Intent i = new Intent(RegisterActivity.this,AboutUs.class);
                startActivity(i);
                return true;

            default:
                return false;
        }
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    public void RegisterButton(){
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                register.setEnabled(false);
                final String phone,nameT ;
                phone = phoneNum.getText().toString().trim() ;
                nameT = name.getText().toString().trim();
                //check validation
                boolean isValid = validationMethod(phone,nameT);

                if(isValid == false){
                    register.setEnabled(true);
                }
                else {
                    //if all fields are valid then send it to server
                    RegisterActivity.AttempLogin atreg = new RegisterActivity.AttempLogin();
                    atreg.execute(phone,nameT,Integer.toString(gender));

                }

            }
        });
    }



    public boolean validationMethod(String phone,String nameT)
    {
        int flag = 0;
        String regexPhone = "^[6-9][0-9]{9}$";
        String regxName = "^[a-zA-Z]{3}[a-zA-Z]*[ ]?[a-zA-Z]*$";
        if(phone.isEmpty() ){
            Toast.makeText(RegisterActivity.this, "Please Enter Number", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }
        if(nameT.isEmpty()){
            Toast.makeText(RegisterActivity.this, "Please Enter Name", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }
        if(phone.length() != 10 && flag == 0){
            Toast.makeText(RegisterActivity.this, "Invalid Number", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }
        if(!phone.matches(regexPhone) && flag == 0){
            Toast.makeText(RegisterActivity.this, "Invalid Number", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }
        if(!nameT.matches(regxName) && flag == 0){
            Toast.makeText(RegisterActivity.this, "Invalid Name", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }
        if(gender == 0) {
            Toast.makeText(RegisterActivity.this, "Select your gender", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }

        if(flag == 1){
            return false ;
        }
        else{
            return true ;
        }

    }
    public void onGenderButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.radio_male:
                if (checked)
                    gender = 1 ;
                break;
            case R.id.radio_female:
                if (checked)
                    gender = 2 ;
                break;
        }

    }


    //this class updates the local database
    private class AttempLogin extends AsyncTask<String, String, JSONObject> {

        @Override

        protected void onPreExecute() {

            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(RegisterActivity.this);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();
        }

        @Override

        protected JSONObject doInBackground(String... args) {
            ArrayList params = new ArrayList();
            params.add(new BasicNameValuePair("phonenumber", args[0]));
            params.add(new BasicNameValuePair("name", args[1]));
            params.add(new BasicNameValuePair("gender", args[2]));
            JSONObject json = new JSONObject();
            try {
                json = jParser.makeHttpRequest(App_Config_Value.URL_FOR_REGISTERING, "POST", params);


            }catch (Exception e){


                e.printStackTrace();
            }

            System.out.println(json);
            return (json);

        }

        protected void onPostExecute(JSONObject result) {
            try {
                int error = Integer.parseInt(result.getString(App_Config_Value.ERROR_CODE_STRING));


                if (error == App_Config_Value.HTTP_STATUS_CODE_2 ) {

                    String success = result.getString(App_Config_Value.SUCCESS);
                    String message = result.getString(App_Config_Value.MESSAGE);
                    if(success.equals(App_Config_Value.SER_REG_TRUE)){
                        Toast.makeText(RegisterActivity.this,message, Toast.LENGTH_SHORT).show();
                        String phone = result.getString(App_Config_Value.PHONE);
                        String name = result.getString(App_Config_Value.NAME);
                        //Send Intent to Verification
                        Intent i = new Intent(RegisterActivity.this, Register2.class);
                        i.putExtra(App_Config_Value.PHONE, phone);
                        i.putExtra(App_Config_Value.NAME, name);
                        startActivity(i);
                        finish();


                    }
                    else {
                        Toast.makeText(RegisterActivity.this,message,Toast.LENGTH_SHORT).show();
                        register.setEnabled(true);
                    }
                }else {


                    Toast.makeText(RegisterActivity.this, "" + result.get(App_Config_Value.ERROR_MESSAGE), Toast.LENGTH_SHORT).show();

                }
            } catch (JSONException e) {
                Toast.makeText(RegisterActivity.this, "No Internet Connection", Toast.LENGTH_SHORT).show();

            }


            // Dismiss the progress dialog
            if (pDialog.isShowing())
                pDialog.dismiss();


        }

    }





}

