package vistarnet.manu.com.flavaco;

/**
 * Created by manish channawar on 03-11-2018.
 */

public class hotelDBInfo {
    public static final String TABLE_NAME = "hotel";

    public static final String COLUMN_ID = "id";
    public static final String COLUMN_HOTEL_PAGE = "hotelpage";
    public static final String COLUMN_HOTEL_IMG = "hotelimg";

    private int id;
    private String hotelpage;
    private String hotelimg;


    // Create table SQL query
    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY ,"
                    + COLUMN_HOTEL_PAGE + " TEXT,"
                    + COLUMN_HOTEL_IMG + " TEXT"
                    + ")";

    public hotelDBInfo() {
    }

    public hotelDBInfo(int id, String hotelpage, String hotelimg) {
        this.id = id;
        this.hotelpage = hotelpage;
        this.hotelimg = hotelimg;
    }


    public hotelDBInfo(int id) {
        this.id = id;

    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String gethotelpage() {
        return hotelpage;
    }

    public void sethotelpage(String hotelpage) {
        this.hotelpage = hotelpage;
    }

    public String getHotelimg() {
        return hotelimg;
    }



    public void setHotelimg(String hotelimg) {
        this.hotelimg = hotelimg;
    }
}
