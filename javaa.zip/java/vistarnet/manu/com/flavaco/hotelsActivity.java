package vistarnet.manu.com.flavaco;

import android.app.ProgressDialog;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.PopupMenu;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;

import android.widget.Button;
import android.widget.Toast;


import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class hotelsActivity extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {


    Button h1,h2,h3,h4,h5,back;
    private ProgressDialog pDialog;
    private static final String TAG_BUTTON = "hotelbutton";
    private static final String TAG_ID = "id";
    private static final String TAG_BUTTON_TEXT = "btext";

    JSONParser jParser = new JSONParser();

    private AdView mAdView;
    private InterstitialAd mInterstitialAd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotels);

        h1 = (Button)findViewById(R.id.h1);
        h2 = (Button)findViewById(R.id.h2);
        h3 = (Button)findViewById(R.id.h3);
        h4 = (Button)findViewById(R.id.h4);
        h5 = (Button)findViewById(R.id.h5);

        back = (Button)findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(hotelsActivity.this,MainActivity.class);
                startActivity(i);
                finish();
            }
        });

        h1.setVisibility(View.INVISIBLE);
        h2.setVisibility(View.INVISIBLE);
        h3.setVisibility(View.INVISIBLE);
        h4.setVisibility(View.INVISIBLE);
        h5.setVisibility(View.INVISIBLE);




        ////////
        MobileAds.initialize(this, "ca-app-pub-2170195758235926~2230171851");
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("ca-app-pub-2170195758235926/3607666858");
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                // Load the next interstitial.
                mInterstitialAd.loadAd(new AdRequest.Builder().build());
            }

        });



        /////////
        MobileAds.initialize(this, "ca-app-pub-2170195758235926~2230171851");
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        hotelsActivity.hotelButton attreg = new hotelsActivity.hotelButton();
        attreg.execute("","","");
    }


    public void showMenu(View v) {
        PopupMenu popup = new PopupMenu(this, v);

        // This activity implements OnMenuItemClickListener
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.actions);
        popup.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.aboutus:
                if (mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                } else {
                    Log.d("TAG", "The interstitial wasn't loaded yet.");
                }
                Intent i = new Intent(hotelsActivity.this,AboutUs.class);
                startActivity(i);
                return true;

            default:
                return false;
        }
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)  {
        if (Integer.parseInt(android.os.Build.VERSION.SDK) > 5
                && keyCode == KeyEvent.KEYCODE_BACK
                && event.getRepeatCount() == 0) {
            //Log.d("CDA", "onKeyDown Called");
            onBackPressed();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }


    @Override
    public void onBackPressed() {
        //Log.d("CDA", "onBackPressed Called");
        Intent i = new Intent(hotelsActivity.this,MainActivity.class);

        startActivity(i);
        finish();
    }





    private class hotelButton extends AsyncTask<String, String, JSONObject> {

        @Override

        protected void onPreExecute() {

            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(hotelsActivity.this);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();
        }

        @Override

        protected JSONObject doInBackground(String... args) {

            ArrayList params = new ArrayList();



            JSONObject json = new JSONObject();
            try {
                json = jParser.makeHttpRequest(App_Config_Value.URL_FOR_HOTELS_BUTTONS, "POST", params);


            }catch (Exception e){


                e.printStackTrace();
            }

            System.out.println(json);
            return (json);

        }

        protected void onPostExecute(JSONObject result) {
            try {
                int error = Integer.parseInt(result.getString(App_Config_Value.ERROR_CODE_STRING));
                if (error == App_Config_Value.HTTP_STATUS_CODE_2){







                    //for the buttons
                    JSONArray buttons = result.getJSONArray(TAG_BUTTON);
                    for (int i = 0; i < buttons.length(); i++) {
                        JSONObject c = buttons.getJSONObject(i);

                        // Storing each json item in variable
                        String id = c.getString(TAG_ID);
                        String text = c.getString(TAG_BUTTON_TEXT);



                        if(id.equals("h1")){
                            h1.setText(text);
                            h1.setVisibility(View.VISIBLE);

                            h1.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent i = new Intent(hotelsActivity.this,barCodeActivity.class);
                                    i.putExtra(App_Config_Value.INTENT_ACTIVITY_ID,2);
                                    startActivity(i);
                                    finish();


                                }
                            });

                        }
                        if(id.equals("h2")){

                            h2.setVisibility(View.VISIBLE);
                            h2.setText(text);
                            h2.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent i = new Intent(hotelsActivity.this,barCodeActivity.class);
                                    i.putExtra(App_Config_Value.INTENT_ACTIVITY_ID,2);
                                    startActivity(i);
                                    finish();

                                }
                            });

                        }
                        if(id.equals("h3")){

                            h3.setVisibility(View.VISIBLE);
                            h3.setText(text);
                            h3.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent i = new Intent(hotelsActivity.this,barCodeActivity.class);
                                    i.putExtra(App_Config_Value.INTENT_ACTIVITY_ID,2);
                                    startActivity(i);
                                    finish();

                                }
                            });

                        }
                        if(id.equals("h4")){

                            h4.setVisibility(View.VISIBLE);
                            h4.setText(text);
                            h4.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent i = new Intent(hotelsActivity.this,barCodeActivity.class);
                                    i.putExtra(App_Config_Value.INTENT_ACTIVITY_ID,2);
                                    startActivity(i);
                                    finish();

                                }
                            });

                        }
                        if(id.equals("h5")){

                            h5.setVisibility(View.VISIBLE);
                            h5.setText(text);
                            h5.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent i = new Intent(hotelsActivity.this,barCodeActivity.class);
                                    i.putExtra(App_Config_Value.INTENT_ACTIVITY_ID,2);
                                    startActivity(i);
                                    finish();

                                }
                            });

                        }


                    }





                }
                else{
                    Toast.makeText(hotelsActivity.this, "" + result.get(App_Config_Value.ERROR_MESSAGE), Toast.LENGTH_SHORT).show();
                }

            } catch (JSONException e) {
                Toast.makeText(hotelsActivity.this, "JSON ERROR", Toast.LENGTH_SHORT).show();

            }catch (Exception e1){
                Log.e("JSON Parser", "Error parsing data " + e1.toString());
            }


            // Dismiss the progress dialog
            if (pDialog.isShowing())
                pDialog.dismiss();


        }

    }
}

