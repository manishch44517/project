package vistarnet.manu.com.flavaco;

import android.app.ProgressDialog;
import android.content.Context;

import android.content.Intent;
import android.content.SharedPreferences;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.PopupMenu;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import android.widget.Button;

import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;

import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {

    Button b1,b2,b3,b4,b5;
    private ProgressDialog pDialog;

    JSONParser jParser = new JSONParser();


    private static final String TAG_HOTELS = "hotels";
    private static final String TAG_ID = "id";
    private static final String TAG_HOTELURL = "pageurl";
    private static final String TAG_HOTELIMG = "image";



    private static final String TAG_BUTTONS = "button";
    private static final String TAG_ID_B = "id";
    private static final String TAG_BUTTON_TEXT = "text";
    private static final String TAG_BUTTON_CLASS = "class";
    private static final String TAG_BUTTON_URL = "url";
    private DatabaseHelper db;


    private AdView mAdView;
    private InterstitialAd mInterstitialAd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1 = (Button)findViewById(R.id.b1);
        b2 = (Button)findViewById(R.id.b2);
        b3 = (Button)findViewById(R.id.b3);
        b4 = (Button)findViewById(R.id.b4);
        b5 = (Button)findViewById(R.id.b5);

        b1.setVisibility(View.INVISIBLE);
        b2.setVisibility(View.INVISIBLE);
        b3.setVisibility(View.INVISIBLE);
        b4.setVisibility(View.INVISIBLE);
        b5.setVisibility(View.INVISIBLE);

        ////////
        MobileAds.initialize(this, "ca-app-pub-2170195758235926~2230171851");
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("ca-app-pub-2170195758235926/3607666858");
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                // Load the next interstitial.
                mInterstitialAd.loadAd(new AdRequest.Builder().build());
            }

        });



        /////////
        MobileAds.initialize(this, "ca-app-pub-2170195758235926~2230171851");
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);



        db = new DatabaseHelper(this);

        SharedPreferences prefs = getSharedPreferences(App_Config_Value.MY_SHRD_PREFS_NAME, Context.MODE_PRIVATE);
        int ver = prefs.getInt(App_Config_Value.SHRD_VERSION_KEY, 0); //0 is the default value.

        MainActivity.hotelAndButtons atreg = new MainActivity.hotelAndButtons();
        atreg.execute(""+ver,"","");


    }

    public void showMenu(View v) {
        PopupMenu popup = new PopupMenu(this, v);

        // This activity implements OnMenuItemClickListener
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.actions);
        popup.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.aboutus:
                if (mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                } else {
                    Log.d("TAG", "The interstitial wasn't loaded yet.");
                }
                Intent i = new Intent(MainActivity.this,AboutUs.class);
                startActivity(i);
                return true;

            default:
                return false;
        }
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }





    private class hotelAndButtons extends AsyncTask<String, String, JSONObject> {

        @Override

        protected void onPreExecute() {

            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(MainActivity.this);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();
        }

        @Override

        protected JSONObject doInBackground(String... args) {

            ArrayList params = new ArrayList();
            params.add(new BasicNameValuePair("version", args[0]));


            JSONObject json = new JSONObject();
            try {
                json = jParser.makeHttpRequest(App_Config_Value.URL_FOR_BUTTON_HOTEL, "POST", params);


            }catch (Exception e){


                e.printStackTrace();
            }

            System.out.println(json);
            return (json);

        }

        protected void onPostExecute(JSONObject result) {
            try {
                int error = Integer.parseInt(result.getString(App_Config_Value.ERROR_CODE_STRING));
                if (error == App_Config_Value.HTTP_STATUS_CODE_2){



                    //put the values in the database
                    int Server_vercode = Integer.parseInt(result.getString(App_Config_Value.VERSION));
                    SharedPreferences prefs = getSharedPreferences(App_Config_Value.MY_SHRD_PREFS_NAME, Context.MODE_PRIVATE);
                    int client_vercode = prefs.getInt(App_Config_Value.SHRD_VERSION_KEY, 0);

                    if(Server_vercode >  client_vercode && Server_vercode != 0){
                        JSONArray hotels = result.getJSONArray(TAG_HOTELS);

                        SharedPreferences.Editor editor = getSharedPreferences(App_Config_Value.MY_SHRD_PREFS_NAME, Context.MODE_PRIVATE).edit();
                        editor.putInt(App_Config_Value.SHRD_VERSION_KEY,Server_vercode);
                        editor.apply();

                        if(db.getHotelCount() != 0 )
                            db.deleteAllRows();

                        for (int i = 0; i < hotels.length(); i++) {
                            JSONObject c = hotels.getJSONObject(i);

                            // Storing each json item in variable
                            int id = Integer.parseInt(c.getString(TAG_ID));
                            String hotelURL = c.getString(TAG_HOTELURL);
                            String hotelIMG = c.getString(TAG_HOTELIMG);

                            db.insertNote(id,hotelURL,hotelIMG);

                        }

                    }
                    else{
                        if(Server_vercode == client_vercode ){
                            //do nothing
                        }
                        else {
                            Toast.makeText(MainActivity.this, "" + result.get(App_Config_Value.ERROR_MESSAGE), Toast.LENGTH_SHORT).show();
                        }
                    }



                    //for the buttons
                    JSONArray buttons = result.getJSONArray(TAG_BUTTONS);
                    for (int i = 0; i < buttons.length(); i++) {
                        JSONObject c = buttons.getJSONObject(i);

                        // Storing each json item in variable
                        String id = c.getString(TAG_ID_B);
                        String text = c.getString(TAG_BUTTON_TEXT);
                        final String class_name = c.getString(TAG_BUTTON_CLASS);
                        final String url = c.getString(TAG_BUTTON_URL);
                        //final Class<?> Z = ScanActivity.class;

                        if(id.equals("b1")){
                            b1.setText(text);
                            b1.setVisibility(View.VISIBLE);

                            b1.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent i = new Intent(MainActivity.this,ImageLoader2.class);
                                    i.putExtra(App_Config_Value.INTENT_ACTIVITY_ID,1);
                                    startActivity(i);
                                    finish();


                                }
                            });

                        }
                        if(id.equals("b2")){

                            b2.setVisibility(View.VISIBLE);
                            b2.setText(text);
                            b2.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent i = new Intent(MainActivity.this,ImageLoader2.class);
                                    i.putExtra(App_Config_Value.INTENT_ACTIVITY_ID,3);
                                    i.putExtra(App_Config_Value.INTENT_ACTIVITY_URL,url);
                                    startActivity(i);
                                    finish();

                                }
                            });

                        }
                        if(id.equals("b3")){

                            b3.setVisibility(View.VISIBLE);
                            b3.setText(text);
                            b3.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent i = new Intent(MainActivity.this,ImageLoader2.class);
                                    i.putExtra(App_Config_Value.INTENT_ACTIVITY_ID,4);
                                    i.putExtra(App_Config_Value.INTENT_ACTIVITY_URL,url);
                                    startActivity(i);
                                    finish();

                                }
                            });

                        }
                        if(id.equals("b4")){

                            b4.setVisibility(View.VISIBLE);
                            b4.setText(text);
                            b4.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent i = new Intent(MainActivity.this,ImageLoader2.class);
                                    i.putExtra(App_Config_Value.INTENT_ACTIVITY_ID,5);
                                    i.putExtra(App_Config_Value.INTENT_ACTIVITY_URL,url);
                                    startActivity(i);
                                    finish();

                                }
                            });

                        }
                        if(id.equals("b5")){

                            b5.setVisibility(View.VISIBLE);
                            b5.setText(text);
                            b5.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent i = new Intent(MainActivity.this,ImageLoader2.class);
                                    i.putExtra(App_Config_Value.INTENT_ACTIVITY_ID,6);
                                    i.putExtra(App_Config_Value.INTENT_ACTIVITY_URL,url);
                                    startActivity(i);
                                    finish();

                                }
                            });

                        }


                    }





                }
                else{
                    Toast.makeText(MainActivity.this, "" + result.get(App_Config_Value.ERROR_MESSAGE), Toast.LENGTH_SHORT).show();
                }

            } catch (JSONException e) {
                Toast.makeText(MainActivity.this, "JSON ERROR", Toast.LENGTH_SHORT).show();

            }catch (Exception e1){
               // Log.e("JSON Parser", "Error parsing data " + e1.toString());
            }


            // Dismiss the progress dialog
            if (pDialog.isShowing())
                pDialog.dismiss();


        }

    }



}
