package vistarnet.manu.com.flavaco;

/**
 * Created by manish channawar on 03-11-2018.
 */

public class App_Config_Value {
    public static int HTTP_STATUS_CODE_1 = 1 ;
    public static int HTTP_STATUS_CODE_2 = 2 ;
    public static int HTTP_STATUS_CODE_3 = 3 ;
    public static int HTTP_STATUS_CODE_4 = 4 ;
    public static int HTTP_STATUS_CODE_5 = 5 ;

    public static int HTTP_STATUS_TIMEOUT = 9999 ;
    public static String ERROR_CODE_STRING = "error_code";

    public static String ERROR_MESSAGE = "error_message";

    public static String VERSION = "version";

    public static String SHRD_VERSION_KEY = "version" ;
    public static String SHRD_PHONE_KEY = "phone" ;
    public static String SHRD_NAME_KEY = "name" ;
    public static String SHRD_ID_KEY = "hotelID" ;

    public static String URL_FOR_HOTELS = "http://theessengroup.in/essenflavaco94498/newVer/hotelInfo/hotelsInfo.php" ;//"http://192.168.1.4/flavaco/flavacov1/hotelsInfo.php" ;
    public static String URL_FOR_REGISTERING ="http://theessengroup.in/essenflavaco94498/newVer/RegisterUser/Register_start.php"; //"http://192.168.1.4/flavaco/flavacov1/RegisterUser/Register_start.php" ;
    public static String URL_FOR_OTP_VERIFICATION ="http://theessengroup.in/essenflavaco94498/newVer/RegisterUser/verify_otp_start.php"; //"http://192.168.1.4/flavaco/flavacov1/RegisterUser/verify_otp_start.php" ;
    public static String URL_FOR_COUPON = "http://theessengroup.in/essenflavaco94498/newVer/couponUser/coupon_start.php";//"http://192.168.1.4/flavaco/flavacov1/couponUser/coupon_start.php";
    public static String URL_FOR_BUTTON_HOTEL = "http://theessengroup.in/essenflavaco94498/newVer/hotelURLIMAGE/main_start.php";//http://192.168.1.4/flavaco/flavaco2/main_start.php";
    public static String URL_FOR_HOTELS_BUTTONS = "http://theessengroup.in/essenflavaco94498/newVer/hotelbutton/hotel_button_start.php";//"http://192.168.1.4/flavaco/flavacov1/hotelbutton/hotel_button_start.php";
    public static final String MY_SHRD_PREFS_NAME = "MyPrefsFile";


    public static String SUCCESS = "success";
    public static String MESSAGE = "message";

    //these are the server retuen values
    public static String SER_REG_TRUE = "r1";
    public static String SER_REG_FALSE = "r0";


    public static String SER_OTP_TRUE = "o1";
    public static String SER_OTP_FALSE = "o0";

    public static String SER_COUPON_TRUE = "c1";
    public static String SER_COUPON_FALSE = "c0";



    public static String PHONE = "phone";
    public static String NAME = "name";



    public static String URL_FOR_PENDRIVE = "" ;
    public static String URL_FOR_CLOTHING = "" ;
    public static String URL_FOR_TEMPERED = "" ;
    public static String URL_FOR_EXTRA = "";



    public static String INTENT_ACTIVITY_ID = "activityID";
    public static String INTENT_ACTIVITY_URL = "activityURL";



    public static String COUPON_IMAGE = "imageURL";
    public static String COUPON_HOTEL_ID = "hotelId";
    public static String COUPON_TIMER = "timer";
}
