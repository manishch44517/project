package vistarnet.manu.com.flavaco;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.widget.Toast;

import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by manish channawar on 29-10-2018.
 */

public class HotelListDownloader {



    private ProgressDialog pDialog;
    // Creating JSON Parser object
    JSONParser jParser = new JSONParser();

    private static final String TAG_HOTELS = "hotels";
    private static final String TAG_ID = "id";
    private static final String TAG_HOTELURL = "pageurl";
    private static final String TAG_HOTELIMG = "image";
    private DatabaseHelper db;

    Context context;

    // Constructor
    HotelListDownloader(Context context) {
        this.context = context;
    }



    public void checkAndDownloadHotels()
    {
        db = new DatabaseHelper(context);
        int countOfRows = db.getHotelCount() ;




        if(countOfRows==0){

            HotelListDownloader.LoadHotels atreg = new HotelListDownloader.LoadHotels();
            atreg.execute("1","","");


        }
        else {

            SharedPreferences prefs = context.getSharedPreferences(App_Config_Value.MY_SHRD_PREFS_NAME, context.MODE_PRIVATE);
            int ver = prefs.getInt(App_Config_Value.SHRD_VERSION_KEY, 0); //0 is the default value.
            HotelListDownloader.LoadHotels atreg = new HotelListDownloader.LoadHotels();
            atreg.execute(""+ver,"","");


        }
    }



    //this class updates the local database
    private class LoadHotels extends AsyncTask<String, String, JSONObject> {

        @Override

        protected void onPreExecute() {

            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(context);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();
        }

        @Override

        protected JSONObject doInBackground(String... args) {
            ArrayList params = new ArrayList();
            params.add(new BasicNameValuePair("version", args[0]));
            JSONObject json = new JSONObject();
            try {
                json = jParser.makeHttpRequest(App_Config_Value.URL_FOR_HOTELS, "POST", params);


            }catch (Exception e){


                e.printStackTrace();
            }

            System.out.println(json);
            return (json);

        }

        protected void onPostExecute(JSONObject result) {
            try {
                int error = Integer.parseInt(result.getString(App_Config_Value.ERROR_CODE_STRING));
                int vercode = Integer.parseInt(result.getString(App_Config_Value.VERSION));
                SharedPreferences prefs = context.getSharedPreferences(App_Config_Value.MY_SHRD_PREFS_NAME, context.MODE_PRIVATE);
                int ver = prefs.getInt(App_Config_Value.SHRD_VERSION_KEY, 0); //0 is the default value.
                if (error == App_Config_Value.HTTP_STATUS_CODE_2 && vercode > ver && vercode != 0) {

                    JSONArray hotels = result.getJSONArray(TAG_HOTELS);

                    SharedPreferences.Editor editor = context.getSharedPreferences(App_Config_Value.MY_SHRD_PREFS_NAME, context.MODE_PRIVATE).edit();
                    editor.putInt(App_Config_Value.SHRD_VERSION_KEY,vercode);
                    editor.putInt(App_Config_Value.SHRD_ID_KEY,Integer.parseInt(result.getJSONArray(TAG_HOTELS).getJSONObject(0).getString(TAG_ID)));
                    editor.apply();

                    if(db.getHotelCount() != 0 )
                        db.deleteAllRows();

                    for (int i = 0; i < hotels.length(); i++) {
                        JSONObject c = hotels.getJSONObject(i);

                        // Storing each json item in variable
                        int id = Integer.parseInt(c.getString(TAG_ID));
                        String hotelURL = c.getString(TAG_HOTELURL);
                        String hotelIMG = c.getString(TAG_HOTELIMG);

                        db.insertNote(id,hotelURL,hotelIMG);

                    }








                }else {
                    if(vercode == ver ){

                    }
                    else {
                        Toast.makeText(context, "" + result.get(App_Config_Value.ERROR_MESSAGE), Toast.LENGTH_SHORT).show();
                    }
                }
            } catch (JSONException e) {
                Toast.makeText(context, "JSON ERROR", Toast.LENGTH_SHORT).show();

            }
            db.close();

            // Dismiss the progress dialog
            if (pDialog.isShowing())
                pDialog.dismiss();


        }

    }
}
