package example.com.cambulance;

/**
 * Created by manish channawar on 11-06-2019.
 */

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.http.impl.client.DefaultHttpClient;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.http.impl.client.DefaultHttpClient;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

public class JSONParser {
    static InputStream is = null;
    static JSONObject jObj = null;

    static String json = "";
    static String error = "";
    int error_start_code ;

    // constructor
    public JSONParser() {

    }

    public JSONObject makeHttpRequest(String url, String method, ArrayList params) {


        try {

            // check for request method

            HttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            httpPost.setEntity(new UrlEncodedFormEntity(params));
            try {
                //Log.e("API123", " " + convertStreamToString(httpPost.getEntity().getContent()));
                // Log.e("API123", httpPost.getURI().toString());
            } catch (Exception e) {
                e.printStackTrace();

            }

            HttpResponse httpResponse = httpClient.execute(httpPost);
            //Log.e("API123", "" + httpResponse.getStatusLine().getStatusCode());

            error = String.valueOf(httpResponse.getStatusLine().getStatusCode());
            error_start_code = Integer.parseInt(error);
            error_start_code = error_start_code / 100 ;
            //System.out.println(error_start_code);



            HttpEntity httpEntity = httpResponse.getEntity();

            is = httpEntity.getContent();


        }catch (HttpHostConnectException e){

            error_start_code = App_config.HTTP_STATUS_TIMEOUT ;

        }
        catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }



        if(error_start_code != App_config.HTTP_STATUS_TIMEOUT ) {
            try {

                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        is, "iso-8859-1"), 8);
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                is.close();
                json = sb.toString();
                //Log.d("API123", json);


            } catch (Exception e) {
                //Log.e("Buffer Error", "Error converting result " + e.toString());
            }
        }

        // try to parse the string to a JSON object
        if(error_start_code == App_config.HTTP_STATUS_CODE_2 && error_start_code != App_config.HTTP_STATUS_TIMEOUT ) {
            try {

                jObj = new JSONObject(json);
                jObj.put(App_config.ERROR_CODE_STRING, error_start_code);
                System.out.println(jObj);


            } catch (JSONException e) {
                //Log.e("JSON Parser", "Error parsing data " + e.toString());
            }
        }
        else{
            jObj = new JSONObject();
            try {
                jObj.put(App_config.ERROR_CODE_STRING, error_start_code);
                jObj.put(App_config.VERSION,0);

                if(error_start_code == App_config.HTTP_STATUS_CODE_1 ){
                    jObj.put(App_config.ERROR_MESSAGE,"Informational response");
                }

                if(error_start_code == App_config.HTTP_STATUS_CODE_3 ){
                    jObj.put(App_config.ERROR_MESSAGE,"Redirection");
                }
                if(error_start_code == App_config.HTTP_STATUS_CODE_4 ){
                    jObj.put(App_config.ERROR_MESSAGE,"Client error");
                }
                if(error_start_code == App_config.HTTP_STATUS_CODE_5 ){
                    jObj.put(App_config.ERROR_MESSAGE,"Server under maintenance");
                }

                if(error_start_code == App_config.HTTP_STATUS_TIMEOUT ){
                    jObj.put(App_config.ERROR_MESSAGE,"Server Unreachable Please try Again!");
                }
                //System.out.println(jObj);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        // return JSON String
        return jObj;
    }

    private String convertStreamToString(InputStream is) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();
        String line ;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        is.close();
        return sb.toString();
    }
}


