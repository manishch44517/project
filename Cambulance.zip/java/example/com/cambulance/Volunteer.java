package example.com.cambulance;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Volunteer extends AppCompatActivity {
    Button register ;
    EditText phoneNum,name,No1,No2,No3,No4;
    private ProgressDialog pDialog;

    JSONParser jParser = new JSONParser();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_volunteer);



        phoneNum = (EditText)findViewById(R.id.mobile);
        name = (EditText)findViewById(R.id.Name);
        No1 = (EditText)findViewById(R.id.No1);
        No2 = (EditText)findViewById(R.id.No2);
        No3 = (EditText)findViewById(R.id.No3);
        No4 = (EditText)findViewById(R.id.No4);
        register = (Button)findViewById(R.id.Register);

        Register();

    }

    private void Register() {
        register.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                final String phone,nameT,no1,no2,no3,no4 ;
                phone = phoneNum.getText().toString().trim() ;
                nameT = name.getText().toString().trim();
                no1 = No1.getText().toString().trim();
                no2 = No2.getText().toString().trim();
                no3 = No3.getText().toString().trim();
                no4 = No4.getText().toString().trim();

                boolean isValid = validationMethod(phone,nameT,no1,no2,no3,no4);

                if(isValid == false){

                }
                else {
                    String VNumber = no1 + no2 + no3 + no4 ;

                    //Send Values to database and shared preference

                    //Go to the other activity


                    //terminate this activity

                    //try to send the phone number to another activity

                    Intent i = new Intent(Volunteer.this,NotifyInfo.class);
                    startActivity(i);


                }








            }
        });
    }


    private class VolunteerAsync extends AsyncTask<String, String, JSONObject> {

        @Override

        protected void onPreExecute() {

            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(Volunteer.this);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();
        }

        @Override

        protected JSONObject doInBackground(String... args) {

            ArrayList params = new ArrayList();
            params.add(new BasicNameValuePair("version", args[0]));


            JSONObject json = new JSONObject();
            try {
                json = jParser.makeHttpRequest(App_config.URL_REGISTER_VOLUNTEER, "POST", params);


            }catch (Exception e){


                e.printStackTrace();
            }

            System.out.println(json);
            return (json);

        }

        protected void onPostExecute(JSONObject result) {
            try {
                int error = Integer.parseInt(result.getString(App_config.ERROR_CODE_STRING));
                if (error == App_config.HTTP_STATUS_CODE_2){



                    //put the values in the database
                    int Server_vercode = Integer.parseInt(result.getString(App_config.VERSION));
                    SharedPreferences prefs = getSharedPreferences(App_config.MY_SHRD_PREFS_NAME, Context.MODE_PRIVATE);
                    int client_vercode = prefs.getInt(App_config.SHRD_VERSION_KEY, 0);

                    if(Server_vercode >  client_vercode && Server_vercode != 0){
                        JSONArray hotels = result.getJSONArray(TAG_HOTELS);

                        SharedPreferences.Editor editor = getSharedPreferences(App_config.MY_SHRD_PREFS_NAME, Context.MODE_PRIVATE).edit();
                        editor.putInt(App_config.SHRD_VERSION_KEY,Server_vercode);
                        editor.apply();

                        if(db.getHotelCount() != 0 )
                            db.deleteAllRows();

                        for (int i = 0; i < hotels.length(); i++) {
                            JSONObject c = hotels.getJSONObject(i);

                            // Storing each json item in variable
                            int id = Integer.parseInt(c.getString(TAG_ID));
                            String hotelURL = c.getString(TAG_HOTELURL);
                            String hotelIMG = c.getString(TAG_HOTELIMG);

                            db.insertNote(id,hotelURL,hotelIMG);

                        }

                    }
                    else{
                        if(Server_vercode == client_vercode ){
                            //do nothing
                        }
                        else {
                            Toast.makeText(Volunteer.this, "" + result.get(App_config.ERROR_MESSAGE), Toast.LENGTH_SHORT).show();
                        }
                    }



                    //for the buttons
                    JSONArray buttons = result.getJSONArray(TAG_BUTTONS);
                    for (int i = 0; i < buttons.length(); i++) {
                        JSONObject c = buttons.getJSONObject(i);

                        // Storing each json item in variable
                        String id = c.getString(TAG_ID_B);
                        String text = c.getString(TAG_BUTTON_TEXT);
                        final String class_name = c.getString(TAG_BUTTON_CLASS);
                        final String url = c.getString(TAG_BUTTON_URL);
                        //final Class<?> Z = ScanActivity.class;

                        if(id.equals("b1")){
                            b1.setText(text);
                            b1.setVisibility(View.VISIBLE);

                            b1.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent i = new Intent(MainActivity.this,ImageLoader2.class);
                                    i.putExtra(App_config.INTENT_ACTIVITY_ID,1);
                                    startActivity(i);
                                    finish();


                                }
                            });

                        }
                        if(id.equals("b2")){

                            b2.setVisibility(View.VISIBLE);
                            b2.setText(text);
                            b2.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent i = new Intent(MainActivity.this,ImageLoader2.class);
                                    i.putExtra(App_config.INTENT_ACTIVITY_ID,3);
                                    i.putExtra(App_config.INTENT_ACTIVITY_URL,url);
                                    startActivity(i);
                                    finish();

                                }
                            });

                        }
                        if(id.equals("b3")){

                            b3.setVisibility(View.VISIBLE);
                            b3.setText(text);
                            b3.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent i = new Intent(MainActivity.this,ImageLoader2.class);
                                    i.putExtra(App_config.INTENT_ACTIVITY_ID,4);
                                    i.putExtra(App_config.INTENT_ACTIVITY_URL,url);
                                    startActivity(i);
                                    finish();

                                }
                            });

                        }
                        if(id.equals("b4")){

                            b4.setVisibility(View.VISIBLE);
                            b4.setText(text);
                            b4.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent i = new Intent(MainActivity.this,ImageLoader2.class);
                                    i.putExtra(App_config.INTENT_ACTIVITY_ID,5);
                                    i.putExtra(App_config.INTENT_ACTIVITY_URL,url);
                                    startActivity(i);
                                    finish();

                                }
                            });

                        }
                        if(id.equals("b5")){

                            b5.setVisibility(View.VISIBLE);
                            b5.setText(text);
                            b5.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent i = new Intent(MainActivity.this,ImageLoader2.class);
                                    i.putExtra(App_config.INTENT_ACTIVITY_ID,6);
                                    i.putExtra(App_config.INTENT_ACTIVITY_URL,url);
                                    startActivity(i);
                                    finish();

                                }
                            });

                        }


                    }





                }
                else{
                    Toast.makeText(MainActivity.this, "" + result.get(App_config.ERROR_MESSAGE), Toast.LENGTH_SHORT).show();
                }

            } catch (JSONException e) {
                Toast.makeText(MainActivity.this, "JSON ERROR", Toast.LENGTH_SHORT).show();

            }catch (Exception e1){
                // Log.e("JSON Parser", "Error parsing data " + e1.toString());
            }


            // Dismiss the progress dialog
            if (pDialog.isShowing())
                pDialog.dismiss();


        }

    }
    private boolean validationMethod(String ph,String name , String n1 , String n2,String n3 , String n4){
        int flag = 0;
        String regexPhone = "^[6-9][0-9]{9}$";
        String regexN2 = "[0-9]{2}";
        String regexN4 = "[0-9]{4}";
        String regexN13 = "[a-zA-Z]{2}";
        String regxName = "^[a-zA-Z]{3}[a-zA-Z]*[ ]?[a-zA-Z]*$";
        if(ph.isEmpty() ){
            Toast.makeText(Volunteer.this, "Please Enter Number", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }
        if(name.isEmpty()){
            Toast.makeText(Volunteer.this, "Please Enter Name", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }
        if(ph.length() != 10 && flag == 0){
            Toast.makeText(Volunteer.this, "Invalid Number", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }
        if(!ph.matches(regexPhone) && flag == 0){
            Toast.makeText(Volunteer.this, "Invalid Number", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }
        if(!name.matches(regxName) && flag == 0){
            Toast.makeText(Volunteer.this, "Invalid Name", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }

        if(n1.isEmpty() || n2.isEmpty() || n3.isEmpty() || n4.isEmpty()){
            Toast.makeText(Volunteer.this, "Enter Vehicle number", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }
        if(!n1.matches(regexN13) && flag == 0){
            Toast.makeText(Volunteer.this, "Invalid Vechicle Number", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }

        if(!n2.matches(regexN2) && flag == 0){
            Toast.makeText(Volunteer.this, "Invalid Vechicle Number", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }

        if(!n3.matches(regexN13) && flag == 0){
            Toast.makeText(Volunteer.this, "Invalid Vechicle Number", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }

        if(!n4.matches(regexN4) && flag == 0){
            Toast.makeText(Volunteer.this, "Invalid Vechicle Number", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }


        if(flag == 1){
            return false ;
        }
        else{
            return true ;
        }

    }
}
