package example.com.cambulance;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;


public class NotifyInfo extends AppCompatActivity {

    Button notification,inform ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notify_info);

        notification = (Button)findViewById(R.id.notification);
        inform = (Button)findViewById(R.id.inform);


        notification.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent(NotifyInfo.this,Notification.class);
                startActivity(i);

            }
        });

        inform.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent(NotifyInfo.this,Inform.class);
                startActivity(i);
            }
        });

    }
}
