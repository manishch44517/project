package example.com.cambulance;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class HospitalRegister extends AppCompatActivity {

    EditText hname , haddr , hreg ,hphone ;
    Button register ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospital_register);

        hname = (EditText)findViewById(R.id.Hname);
        haddr = (EditText)findViewById(R.id.Haddr);
        hreg = (EditText)findViewById(R.id.HReg);
        hphone = (EditText)findViewById(R.id.HPhone);

        register = (Button)findViewById(R.id.HREGISTER);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String HNAME , HADDR , HREG ,HPHONE ;
                HNAME = hname.getText().toString().trim();
                HADDR = haddr.getText().toString().trim();
                HREG = hreg.getText().toString().trim();
                HPHONE = hphone.getText().toString().trim();


                boolean isValid = validationMethod(HNAME,HADDR,HREG,HPHONE);

                if(isValid == false){

                }
                else {


                    //Send Values to database and shared preference

                    //Go to the other activity


                    //terminate this activity

                    //try to send the phone number to another activity

                    Intent i = new Intent(HospitalRegister.this,HospitalMain.class);
                    startActivity(i);


                }



            }
        });
    }
    private boolean validationMethod(String HNAME,String HADDR , String HREG , String HPHONE){
        int flag = 0;
        String regexPhone = "^[6-9][0-9]{9}$";
        String regexN2 = "[0-9]{5}";

        String regxName = "^[a-zA-Z]{3}[a-zA-Z]*[ ]?[a-zA-Z]*$";
        if(HNAME.isEmpty() ){
            Toast.makeText(HospitalRegister.this, "Please Enter Number", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }
        if(HADDR.isEmpty()){
            Toast.makeText(HospitalRegister.this, "Please Enter Address", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }
        if(HREG.isEmpty()){
            Toast.makeText(HospitalRegister.this, "Please Enter Registration number", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }

        if(HPHONE.isEmpty()){
            Toast.makeText(HospitalRegister.this, "Please Enter phone", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }
        if(HPHONE.length() != 10 && flag == 0){
            Toast.makeText(HospitalRegister.this, "Invalid Number", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }
        if(!HPHONE.matches(regexPhone) && flag == 0){
            Toast.makeText(HospitalRegister.this, "Invalid Number", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }
        if(!HNAME.matches(regxName) && flag == 0){
            Toast.makeText(HospitalRegister.this, "Invalid Name", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }

        if(!HREG.matches(regexN2) && flag == 0){
            Toast.makeText(HospitalRegister.this, "Registration number should be of length 5", Toast.LENGTH_SHORT).show();
            flag = 1 ;
        }








        if(flag == 1){
            return false ;
        }
        else{
            return true ;
        }

    }
}
