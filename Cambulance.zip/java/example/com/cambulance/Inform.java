package example.com.cambulance;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Inform extends AppCompatActivity {

    Spinner injury_spinner,hospital_spinner ,spinner;
    EditText persons,additionalInfo ;
    Button Submit ;
    String interesting ;
    Integer key ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inform);

        persons = (EditText)findViewById(R.id.NoOfPerson);
        additionalInfo = (EditText)findViewById(R.id.addInfo);


        injury_spinner = (Spinner) findViewById(R.id.injury_type);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.type_injury, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        injury_spinner.setAdapter(adapter);

        injury_spinner.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                interesting = injury_spinner.getItemAtPosition(i).toString();
            }
        });



        final HashMap<Integer, String> hospitalList = new HashMap<Integer, String>() {{
            put(0, "Bob");
            put(1, "Christine");
        }};





        spinner = (Spinner)findViewById(R.id.hospitals);

        List<StringWithTag> itemList = new ArrayList<StringWithTag>();


        for (Map.Entry<Integer, String> entry : hospitalList.entrySet()) {
            Integer key = entry.getKey();
            String value = entry.getValue();


            itemList.add(new StringWithTag(value, key));
        }


        ArrayAdapter<StringWithTag> spinnerAdapter = new ArrayAdapter<StringWithTag>(this, android.R.layout.simple_spinner_item, itemList);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(spinnerAdapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                StringWithTag swt = (StringWithTag) parent.getItemAtPosition(position);
                key = (Integer) swt.tag;
                //Toast.makeText(Inform.this, ""+hospitalList.get(key)+key, Toast.LENGTH_SHORT).show();


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        Submit = (Button)findViewById(R.id.submitInfo);
        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String NoPerson,addInfo,typeInjury,NearHosp ;
                NoPerson = persons.getText().toString().trim() ;
                addInfo = additionalInfo.getText().toString().trim();
                typeInjury = interesting ;
                NearHosp = key.toString();

                Boolean validate = validate(NoPerson,addInfo);
                if(validate){
                    //send values to server
                }
                else{

                }
            }
        });




    }

    private Boolean validate(String noPerson, String addInfo) {
        int flag = 0 ;
        if(noPerson.isEmpty()){
            flag = 1 ;
            Toast.makeText(this, "Please Enter no. of persons", Toast.LENGTH_SHORT).show();

        }

        Pattern p = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(addInfo);
        boolean check = m.find();

        if (check){
            flag =1 ;
            Toast.makeText(this, "Additional Information should contain only alphanumeric", Toast.LENGTH_SHORT).show();
        }


        if(flag == 0){
            return true ;
        }
        else{
            return false ;
        }

    }


    private static class StringWithTag {
        public String string;
        public Object tag;

        public StringWithTag(String string, Object tag) {
            this.string = string;
            this.tag = tag;
        }

        @Override
        public String toString() {
            return string;
        }
    }
}
