package example.com.cambulance;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button hosp,volu ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        SharedPreferences prefs = getSharedPreferences(App_config.MY_SHRD_PREFS_NAME, Context.MODE_PRIVATE);
        int ver = prefs.getInt(App_config.SHRD_VERSION_KEY, 0); //0 is the default value.
        if(ver == 0){
            prefs.edit().putInt(App_config.SHRD_VERSION_KEY,0).commit();
            hosp = (Button)findViewById(R.id.hosptial);
            volu = (Button)findViewById(R.id.volunteer);

            hosp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //send hospital as 1
                    Intent i = new Intent(MainActivity.this,HospitalRegister.class);
                    i.putExtra("VALUE",1);
                    startActivity(i);

                }
            });

            volu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //send volunteer as 2
                    Intent i = new Intent(MainActivity.this,Volunteer.class);
                    i.putExtra("VALUE",2);
                    startActivity(i);



                }
            });

        }
        else{

            if(ver == 1){
                //get all the shared pref and go to the hospital activity

            }
            else{

                //go to Volunteer

            }

        }











    }


}
