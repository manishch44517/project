package ibm.com.government;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

public class JSONParser {
    private static InputStream is = null;
    private static JSONObject jObj = null;

    private static String json = "";
    private static String error = "";
    private int error_start_code;

    // constructor
    public JSONParser() {

    }

    public JSONObject makeHttpRequest(String url, String method, JSONObject params) {
        try {
            HttpClient httpClient = new DefaultHttpClient();
            HttpResponse httpResponse;
            if (method.equals("GET")) {
                HttpGet get = new HttpGet(url);
                httpResponse = httpClient.execute(get);
            } else {
                HttpPost httpPost = new HttpPost(url);
                httpPost.setHeader("CONTENT-TYPE", "application/json");
                StringEntity entity = new StringEntity(params.toString());
                httpPost.setEntity(entity);
                httpResponse = httpClient.execute(httpPost);
            }

            error = String.valueOf(httpResponse.getStatusLine().getStatusCode());
            error_start_code = Integer.parseInt(error);
            error_start_code = error_start_code / 100;

            HttpEntity httpEntity = httpResponse.getEntity();

            is = httpEntity.getContent();


        } catch (HttpHostConnectException e) {

            error_start_code = App_config.HTTP_STATUS_TIMEOUT;

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        if (error_start_code != App_config.HTTP_STATUS_TIMEOUT) {
            try {

                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        is, "iso-8859-1"), 8);
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                is.close();
                json = sb.toString();
            } catch (Exception e) {
            }
        }

        // try to parse the string to a JSON object
        if (error_start_code == App_config.HTTP_STATUS_CODE_2 && error_start_code != App_config.HTTP_STATUS_TIMEOUT) {
            if (null == json || json.trim().isEmpty()) {
                jObj = new JSONObject();
                try {
                    jObj.put(App_config.ERROR_CODE_STRING, error_start_code);
                } catch (JSONException e) {
                }
            } else {
                try {
                    jObj = new JSONObject(json);
                    jObj.put(App_config.ERROR_CODE_STRING, error_start_code);
                    System.out.println(jObj);
                } catch (JSONException e) {
                    JSONArray tempArray;
                    try {
                        jObj = new JSONObject();
                        tempArray = new JSONArray(json);
                        jObj.put(App_config.ERROR_CODE_STRING, error_start_code);
                        jObj.put("result", tempArray);
                    } catch (JSONException e1) {
                        e1.printStackTrace();
                    }
                    System.out.println(jObj);
                }
            }
        } else {
            jObj = new JSONObject();
            try {
                jObj.put(App_config.ERROR_CODE_STRING, error_start_code);
                jObj.put(App_config.VERSION, 0);

                if (error_start_code == App_config.HTTP_STATUS_CODE_1) {
                    jObj.put(App_config.ERROR_MESSAGE, "Informational response");
                }

                if (error_start_code == App_config.HTTP_STATUS_CODE_3) {
                    jObj.put(App_config.ERROR_MESSAGE, "Redirection");
                }
                if (error_start_code == App_config.HTTP_STATUS_CODE_4) {
                    jObj.put(App_config.ERROR_MESSAGE, "Client error");
                }
                if (error_start_code == App_config.HTTP_STATUS_CODE_5) {
                    jObj.put(App_config.ERROR_MESSAGE, "Server under maintenance");
                }

                if (error_start_code == App_config.HTTP_STATUS_TIMEOUT) {
                    jObj.put(App_config.ERROR_MESSAGE, "Server Unreachable Please try Again!");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return jObj;
    }

    private String convertStreamToString(InputStream is) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        is.close();
        return sb.toString();
    }
}
