package ibm.com.government;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;


public class SendNotification extends AppCompatActivity {
    TextView Dname, DLocation;
    Button sendNotification;
    private ProgressDialog pDialog;
    JSONParser jParser = new JSONParser();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_notification);


        Dname = (TextView) findViewById(R.id.Dname);
        DLocation = (TextView) findViewById(R.id.Dlocation);
        sendNotification = (Button) findViewById(R.id.sendNotificationButton);


        //set on click listener for sendNotificationButton
        sendNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String DNAME, DLOCATION;
                DNAME = Dname.getText().toString().trim();
                DLOCATION = DLocation.getText().toString().trim();
                Boolean isValid = validate(DNAME, DLOCATION);
                if (isValid) {
                    //send values to database
                    new SendNotification.SendNotificationAsync().execute(DNAME,DLOCATION);
                } else {

                }
            }
        });
    }

    private Boolean validate(String dname, String dlocation) {
        int flag = 0;
        String regxName = "^[a-zA-Z]{3}[a-zA-Z]*[ ]?[a-zA-Z]*$";
        if (dname.trim().isEmpty()) {
            Toast.makeText(this, "Disaster name empty", Toast.LENGTH_SHORT).show();
            flag = 1;
        }
        if (dlocation.trim().isEmpty()) {
            Toast.makeText(this, "Disaster Location empty", Toast.LENGTH_SHORT).show();
            flag = 1;
        }
        if (flag == 0 && !dname.matches(regxName)) {
            Toast.makeText(this, "Invalid Disaster Name", Toast.LENGTH_SHORT).show();
            flag = 1;
        }

        if (flag == 1) {
            return false;
        } else {
            return true;
        }

    }


    private class SendNotificationAsync extends AsyncTask<String, String, JSONObject> {

        @Override

        protected void onPreExecute() {

            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(SendNotification.this);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();
        }

        @Override

        protected JSONObject doInBackground(String... args) {

            JSONObject obj = new JSONObject();
            try {
                obj.put("name", args[0]);
                obj.put("address", args[1]);

            } catch (JSONException e) {
                e.printStackTrace();
            }

            JSONObject json = new JSONObject();
            try {
                json = jParser.makeHttpRequest(App_config.URL_GENERATE_EVENT_DISASTER, "POST", obj);


            } catch (Exception e) {


                e.printStackTrace();
            }

            System.out.println(json);
            return (json);

        }

        protected void onPostExecute(JSONObject result) {
            try {


                int error = Integer.parseInt(result.getString(App_config.ERROR_CODE_STRING));
                if (error == App_config.HTTP_STATUS_CODE_2) {


                    Toast.makeText(SendNotification.this, "Notified to the volunteers", Toast.LENGTH_SHORT).show();


                    Intent i = new Intent(SendNotification.this, MainActivity.class);
                    startActivity(i);
                    finish();


                } else {
                    Toast.makeText(SendNotification.this, "" + result.get(App_config.ERROR_MESSAGE), Toast.LENGTH_SHORT).show();
                }

            } catch (JSONException e) {
                Toast.makeText(SendNotification.this, "JSON ERROR", Toast.LENGTH_SHORT).show();

            } catch (Exception e1) {
                // Log.e("JSON Parser", "Error parsing data " + e1.toString());
            }


            // Dismiss the progress dialog
            if (pDialog.isShowing())
                pDialog.dismiss();


        }

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (Integer.parseInt(android.os.Build.VERSION.SDK) > 5
                && keyCode == KeyEvent.KEYCODE_BACK
                && event.getRepeatCount() == 0) {
            //Log.d("CDA", "onKeyDown Called");
            onBackPressed();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onBackPressed() {
        // Log.d("CDA", "onBackPressed Called");
        Intent i = new Intent(SendNotification.this, MainActivity.class);
        startActivity(i);
        finish();
    }
}
