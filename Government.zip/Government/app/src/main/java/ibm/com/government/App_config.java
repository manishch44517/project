package ibm.com.government;

public class App_config {
    public static final String MY_SHRD_PREFS_NAME = "MyPrefsFile";
    public static final String SHRD_VERSION_KEY = "version";


    public static final String V_NAME = "vname";
    public static final String V_CAR = "car";
    public static final String V_PHONE = "phone";

    public static final String H_NAME = "hospital_name";
    public static final String H_ADD = "hosptial_addr";
    public static final String H_REG = "hospital_reg";
    public static final String H_PHONE = "hosptial_phone";

    public static int HTTP_STATUS_CODE_1 = 1;
    public static int HTTP_STATUS_CODE_2 = 2;
    public static int HTTP_STATUS_CODE_3 = 3;
    public static int HTTP_STATUS_CODE_4 = 4;
    public static int HTTP_STATUS_CODE_5 = 5;

    public static int HTTP_STATUS_TIMEOUT = 9999;

    public static String ERROR_CODE_STRING = "error_code";

    public static String ERROR_MESSAGE = "error_message";

    public static String VERSION = "version";

    public static String URL_REGISTER_VOLUNTEER = "http://192.168.43.188:8080/volunteer";
    public static String URL_REGISTER_HOSPITAL = "http://192.168.43.188:8080/hospital";
    public static String URL_GET_HOSPITALS = "http://192.168.43.188:8080/hospital?lat=18.599608&lng=73.716222";
    public static String URL_NOTIFY_HOSP = "http://192.168.43.188:8080/notification";
    public static String URL_HOSP_NOTIFICATIONS = "http://192.168.43.188:8080/notification?hostipalId=";
    public static String URL_HOSP_ACK = "http://192.168.43.188:8080/notification/ack/";
    public static String URL_EVENT = "http://192.168.43.188:8080/event";

    public static String URL_GENERATE_EVENT_DISASTER = "http://192.168.43.188:8080/";

    public static String VOLUNTEER_ID = "volunteer_id";

    public static String HOSP_ID = "hospitalid";


}
